<?php

namespace App\Services\Idm;

class ManajemenIdmService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
